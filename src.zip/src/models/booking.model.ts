export class Booking{
    public bookingId:number | undefined;
	public  airline:string | undefined;
	
	public  bookBy:string | undefined;
	public  bookFor:string | undefined; 
	public  email:string | undefined; 
	public  age:number | undefined; 
	public  meal:string | undefined; 
	public  tax:number | undefined;
	public  price:number | undefined;
	public  pnr:string | undefined;
	//private int numberOfSeats;
	public  classType:string | undefined;
	public  flightId:number | undefined;

    constructor(
        age:number,
        bookBy:string,
        bookFor:string,
        email:string,
        meal:string,

    ){
            this.age=age;
            this.bookBy=bookBy;
            this.bookFor=bookFor;
            this.email=email;
            this.meal=meal;

    }
}
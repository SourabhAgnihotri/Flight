export class BookingDetails{

    public flightId:number | undefined;
   
    public fromLocation:string | undefined;
    public toLocation:string | undefined;
    public startDate:string | undefined;
    public endDate:string | undefined;

    constructor(){}
}

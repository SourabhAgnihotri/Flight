export class Flight{

    public flightId:number | undefined;
        public airlines:string | undefined;
        public fromLocation:string | undefined;
        public toLocation:string | undefined;
        public startDate:string | undefined;
        public endDate:string | undefined;
        public scheduleDays:string | undefined;
        public instrument:string | undefined;
        public  businessClassSeats:string | undefined;
        public economyClassSeats:string | undefined;
        public ticketCost:number | undefined;
        public availableEconomySeats:number | undefined;
        public availableBusinessSeats:number | undefined;
        public block:string | undefined;

    constructor(
        fromLocation:string,
        toLocation:string,
        startDate:string,
        
        
        )
        {
            this.fromLocation = fromLocation;
            this.toLocation = toLocation;
            this.startDate = startDate;
            
        }

        
}
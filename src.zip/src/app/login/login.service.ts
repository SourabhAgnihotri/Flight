import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { User } from 'src/models/user.model';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  isLogin = new BehaviorSubject<boolean>(false);

  constructor(private http:HttpClient) { 
  }

login(user : User)
{
  
  return this.http.post("http://3.93.162.18:8081/Auth/login", user);
}

}

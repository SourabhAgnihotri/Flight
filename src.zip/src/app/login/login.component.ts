import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { User } from 'src/models/user.model';
import { AdminService } from '../admin/admin.service';
import { UserService } from '../user/user.service';
import { LoginService } from './login.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm : FormGroup;

  str:string="^[a-zA-Z]$";

  constructor(private loginService : LoginService,
              private router : Router) {
    this.loginForm = new FormGroup({
      'username' : new FormControl('',[Validators.required,Validators.minLength(3),Validators.maxLength(10)]),
      'password' : new FormControl('',[Validators.required,Validators.minLength(5),Validators.maxLength(8)])
    });
   }

  ngOnInit(): void {
  }

  

  login(){
    
    const user = new User(this.loginForm.value['username'], this.loginForm.value['password']);
    this.loginService.login(user).subscribe(
      (response : any) => {
        console.log(response);
        this.loginService.isLogin.next(true);
        localStorage.setItem("token" ,response[0].token);
        if(response[1]==='admin')
        {
          this.router.navigate(['admin']);
        }
        else{
          this.router.navigate(['user']);
        }
       
        
          
   
      }
    );
  }

}

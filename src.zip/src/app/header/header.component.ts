import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoginService } from '../login/login.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
login: boolean  = false;
  constructor(private loginService : LoginService,
              private router : Router) { }

  ngOnInit(): void {
    this.loginService.isLogin.subscribe(
      (val) => {
        this.login = val;
      }
    );
  }

  loginUser(){
    
  }

  logoutUser(){
    localStorage.setItem('token', '');
    this.loginService.isLogin.next(false);
    this.router.navigate(['login']);
  }
}

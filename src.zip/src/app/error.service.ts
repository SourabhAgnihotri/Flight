import { Component, ErrorHandler, Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { MyerrorComponent } from './myerror/myerror.component';

@Injectable({
  providedIn: 'root'
})
export class ErrorService implements ErrorHandler {

  constructor(private router:Router) { }
  handleError(error: any): void {
    this.router.navigate(['error']);
  }
}

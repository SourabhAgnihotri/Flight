import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MyerrorComponent } from './myerror.component';

describe('MyerrorComponent', () => {
  let component: MyerrorComponent;
  let fixture: ComponentFixture<MyerrorComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MyerrorComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MyerrorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-myerror',
  templateUrl: './myerror.component.html',
  styleUrls: ['./myerror.component.css']
})
export class MyerrorComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

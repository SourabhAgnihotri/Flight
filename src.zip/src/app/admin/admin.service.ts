import { HttpClient } from '@angular/common/http';
import { EventEmitter, Injectable } from '@angular/core';
import { Flight } from 'src/models/flight.model';

@Injectable({
  providedIn: 'root'
})
export class AdminService {
  isUpdate :boolean | undefined;
  flightArr: Flight[]=[];
  flight = new Flight('','','');

  constructor(private http:HttpClient) { }

  getAllFlights()
  {
    return this.http.get<Flight[]>("http://3.84.253.157:8095/view");
  }

  deleteFlights(flightId:number)
  {
    return this.http.delete("http://3.84.253.157:8095/delete/"+flightId);
  }

  updateFlights(flight:Flight)
  {
    return this.http.put("http://3.84.253.157:8095/update/",flight);
  }

  addFlights(flight:Flight)
  {
    return this.http.post("http://3.84.253.157:8095/add/",flight);
  }

  setFlightsData(flight:Flight[])
  {
      this.flightArr=flight;
  }
  getFightsData()
  {
      return this.flightArr;
  }

  setFlightDataForUpdate(flight : Flight){
    this.flight = flight;
  }

  getFlightDataForUpdate(){
    return this.flight;
  }

  setIsUpdate(isUpdate:boolean)
  {
      this.isUpdate=isUpdate;
  }

  getIsUpdate()
  {
    return this.isUpdate;
  }
}

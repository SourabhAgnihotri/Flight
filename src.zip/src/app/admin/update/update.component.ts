import { Component, OnInit } from '@angular/core';
import { FormArray, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Flight } from 'src/models/flight.model';
import { AdminComponent } from '../admin.component';
import { AdminService } from '../admin.service';
import {Location, LocationStrategy} from '@angular/common';

@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateComponent implements OnInit {

  updateForm:FormGroup;
  flightData : Flight;
  message:string | undefined;

  constructor(private adminService:AdminService,private location: Location,
            private router:Router,private  route:ActivatedRoute) {
    this.flightData = this.adminService.getFlightDataForUpdate(); 
    this.updateForm=new FormGroup({
      'flightId' :new FormControl(this.flightData.flightId, []),
      'airlines':new FormControl(this.flightData.airlines,[Validators.required]),
      'fromLocation':new FormControl(this.flightData.fromLocation,[Validators.required]),
      'toLocation':new FormControl(this.flightData.toLocation,[Validators.required]),
      'startDate':new FormControl(this.flightData.startDate,[Validators.required]),
      'endDate':new FormControl(this.flightData.endDate,[Validators.required]),
      'scheduleDays':new FormControl(this.flightData.scheduleDays,[Validators.required]),
      'instrument':new FormControl(this.flightData.instrument,[Validators.required]),
      'businessClassSeats':new FormControl(this.flightData.businessClassSeats,[Validators.required]),
      'economyClassSeats':new FormControl(this.flightData.economyClassSeats,[Validators.required]),
      'ticketCost':new FormControl(this.flightData.ticketCost,[Validators.required]),
      'availableEconomySeats':new FormControl(this.flightData.availableEconomySeats,[Validators.required]),
      'availableBusinessSeats':new FormControl(this.flightData.availableBusinessSeats,[Validators.required]),
      'block':new FormControl(this.flightData.block,[Validators.required])


    });
  
  }

  ngOnInit(): void {

  }


  update(form:FormGroup)
  {
      this.adminService.updateFlights(form.value).subscribe({
        next:(res:any)=>{
         // this.adminService.isUpdate.emit(true);
         // this.router.navigate(['admin'])
         this.message="FLight details updated";

        }
      }
      );
  }

  back(){
    this.location.back();
  }
}

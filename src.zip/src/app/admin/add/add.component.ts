import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Flight } from 'src/models/flight.model';
import { AdminService } from '../admin.service';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {

  message:string | undefined;
  addForm:FormGroup;
  constructor(private adminService:AdminService) { 
    this.addForm=new FormGroup({
      flightId:new FormControl('',[]),
      airlines:new FormControl('',[]),
      fromLocation:new FormControl('',[]),
      toLocation:new FormControl('',[]),
      startDate:new FormControl('',[]),
      endDate:new FormControl('',[]),
      scheduleDays:new FormControl('',[]),
      instrument:new FormControl('',[]),
      businessClassSeats:new FormControl('',[]),
      economyClassSeats:new FormControl('',[]),
      ticketCost:new FormControl('',[]),
      availableEconomySeats:new FormControl('',[]),
      availableBusinessSeats:new FormControl('',[]),
      block:new FormControl('',[])


    }
    )
  }

  ngOnInit(): void {
  }
  add(form:FormGroup)
  {
      this.adminService.addFlights(form.value).subscribe({
        next:(res:any)=>{
          this.message="New Flight is added";
          this.addForm.reset();
        }
        
      });
  }

 
  
}

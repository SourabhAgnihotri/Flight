import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { Flight } from 'src/models/flight.model';
import { AdminService } from './admin.service';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  flight:any;
  isUpdate:boolean=false;

  constructor(private adminService:AdminService,private router:Router,
    private route:ActivatedRoute 
    ) { this.isUpdate = false; }

  ngOnInit(): void {
   
    this.getAllMovies();
  }

  getAllMovies()
  {
    this.adminService.getAllFlights().subscribe({
      next:(res:Flight[])=>{
        
        this.adminService.setFlightsData(res);
        this.flight=res;
      }
      
    })
  }

  deleteFlight(flightId:number)
  {
  
    this.adminService.deleteFlights(flightId).subscribe({
      next:(resp:any)=>
      this.getAllMovies()
    })
  }

  updateFlight(flightData : any)
  {
    this.isUpdate=true;
    this.adminService.setFlightDataForUpdate(flightData);
    this.router.navigate(['/admin/update']);
  }

  callAdd(){
    this.router.navigate(['/admin/add']);
  }
}

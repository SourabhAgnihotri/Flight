import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { Router, RouterModule, Routes } from '@angular/router';
import { AdminComponent } from './admin.component';
import { UpdateComponent } from './update/update.component';
import { AuthGuardService } from '../login/auth.guard';
import { AddComponent } from './add/add.component';

const routes:Routes=[
  {
    path:"",
    component:AdminComponent,
    canActivate:[AuthGuardService]
  },
  //children:[
    {path:"update",component:UpdateComponent},
    {path:"add",component:AddComponent}
 // ]
  //},
  

  ]


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterModule.forChild(routes),
   
  ],
  exports:[RouterModule]
})
export class AdminModule { }

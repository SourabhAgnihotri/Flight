import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { UserService } from '../user.service';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-userview',
  templateUrl: './userview.component.html',
  styleUrls: ['./userview.component.css']
})
export class UserviewComponent implements OnInit {

 // isBookingOpen:boolean=false;
  flight:any;
  constructor(private userService : UserService,
              private router:Router,
              private route:ActivatedRoute) { 

    this.load();
  }

  ngOnInit(): void {
  }

  load()
  {
      this.flight=this.userService.getFlight();
  }
  
  bookFlight()
  {
    //this.isBookingOpen=true;
    let classtype = this.route.snapshot.paramMap.get('classtype');
    let numberofseats = this.route.snapshot.paramMap.get('numberofseats');
      this.router.navigate(['booking', classtype, numberofseats]);
  }
}

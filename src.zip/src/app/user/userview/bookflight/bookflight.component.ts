import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Booking } from 'src/models/booking.model';
import { Flight } from 'src/models/flight.model';
import { UserService } from '../../user.service';

@Component({
  selector: 'app-bookflight',
  templateUrl: './bookflight.component.html',
  styleUrls: ['./bookflight.component.css']
})
export class BookflightComponent implements OnInit {

  flight:any;
  service: any;
  message:any;
  classtype : any;
  numberofseats : any;
  bookArr:Booking[]=[];
  flightBooked : boolean = false;

  constructor(private userService:UserService,
              private route:ActivatedRoute) {

    this.loadFlight();
   }

  ngOnInit(): void {
    this.classtype = this.route.snapshot.paramMap.get('classtype');
    this.numberofseats = this.route.snapshot.paramMap.get('numberofseats');
  }
  loadFlight()
  {
    this.flight=this.userService.getFlight();
  }
 
  booking(form:NgForm){
    let value = form.value;
    let flightParams = new Booking(
      value.age,
      value.bookBy,
      value.bookFor,
      value.email,
      value.meal
    );
    this.bookArr.push(flightParams);
      this.userService.bookFlight(this.bookArr,this.numberofseats,this.classtype,this.flight[0].flightId).subscribe({
        next: (res:Booking[])=>{
          console.log()
        console.log("movies are fetched");
        this.userService.setBooking(res[0]);
        this.flightBooked = true;
        this.message="Congratulation your ticket is booked: PNR : "+res[0].pnr;
        form.reset();
        }
      })
  }
}

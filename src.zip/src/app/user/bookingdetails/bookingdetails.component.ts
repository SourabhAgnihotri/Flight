import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { UserService } from '../user.service';

@Component({
  selector: 'app-bookingdetails',
  templateUrl: './bookingdetails.component.html',
  styleUrls: ['./bookingdetails.component.css']
})
export class BookingdetailsComponent implements OnInit {

  callSearch:boolean | undefined



  fl:any

  constructor(private userService:UserService) { 
    this.callSearch=true;
  }

  ngOnInit(): void {
  }

  bookingDetails(form:NgForm){
    
    this.userService.bookingDetails(form.value['pnr']).subscribe({
      next:(resp:any)=>{
        this.userService.setBookDetail(resp);
        this.fl=resp
        this.callSearch=false;
      }
    })
  }

}

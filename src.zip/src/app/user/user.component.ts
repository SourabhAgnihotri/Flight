import { Component, OnInit, Output } from '@angular/core';
import { FormControl, NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';

import { Flight } from 'src/models/flight.model';
import { UserService } from './user.service';
import { UserviewComponent } from './userview/userview.component';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit { 
  //isViewCalled : boolean = false;
  constructor(private service:UserService,private router:Router,private route:ActivatedRoute) { }


  ngOnInit(): void {
    //this.isViewCalled = false;
  }

  search(form:NgForm){
    let value = form.value;
   
    let flightParams = new Flight(
      value.fromLocation,
      value.toLocation,
      value.startDate,
      
    );
    if(value.returnDate==="")
    {

    
      this.service.searchFlight(flightParams, value.classType, value.numberOfSeats).subscribe({
        next: (res:Flight) => {
          console.log()
          console.log("movies are fetched");
          this.service.setFLight(res);
          let classtype = value.classType;
          let numberofseats = value.numberOfSeats;
        // this.isViewCalled = true;
          this.router.navigate(['view',classtype , numberofseats ]);
        
        }
      
      }) 
    }
    else
    {
      this.service.searchRoundTrip(flightParams,form.value['returnDate'], value.classType, value.numberOfSeats).subscribe({
        next: (res:Flight) => {
          console.log()
          console.log("movies are fetched");
          this.service.setFLight(res);
          let returnDate=value.returnDate
          let classtype = value.classType;
          let numberofseats = value.numberOfSeats;
        // this.isViewCalled = true;
         this.service.setReturnDate(returnDate);
          this.router.navigate(['view',classtype , numberofseats ]);
        
        }
      
      }) 
    }

  }
     
  

}

import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Booking } from 'src/models/booking.model';
import { BookingDetails } from 'src/models/bookingDetails.model';
import { Flight } from 'src/models/flight.model';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  public flight = new Flight('', '', '');

  public booking=new Booking(0,'','','','');

  public bookDetails=new BookingDetails();  

 returnDate:string | undefined;

  constructor(private http:HttpClient) { }

  searchFlight(flight:Flight, classType : string, numberOfSeats : number){
    let params = new HttpParams();
 
    params=params.set('classType', classType);
    params=params.set('numberOfSeats', numberOfSeats);
    //return this.http.get("http://host.docker.internal:8095/searchflight/?"+JSON.stringify(params),flight);
    return this.http.post<Flight>("http://3.93.162.18:8081/Auth/searchflight/", flight, {params});
  }

  searchRoundTrip(flight:Flight, returnDate:string, classType : string, numberOfSeats : number){
    let params = new HttpParams();
    params=params.set('returnDate', returnDate);
    params=params.set('classType', classType);
    params=params.set('numberOfSeats', numberOfSeats);
    //return this.http.get("http://host.docker.internal:8095/searchflight/?"+JSON.stringify(params),flight);
    return this.http.post<Flight>("http://3.93.162.18:8081/Auth/searchroundtrip/", flight, {params});
  }

  bookFlight(booking:Booking[], numberOfSeats : number,classType : string,flightId:number ){
    let params = new HttpParams();
    params=params.set('numberOfSeats', numberOfSeats);
    params=params.set('classType', classType);
    params=params.set('flightId',flightId)
    
    //return this.http.get("http://host.docker.internal:8095/searchflight/?"+JSON.stringify(params),flight);
    return this.http.post<Booking[]>("http://3.93.162.18:8081/Auth/bookflight/", booking, {params});
  }

  bookingDetails(pnr:string){
    return this.http.get("http://3.93.162.18:8081/Auth/find/details/"+pnr)
  }

  public setFLight(flight:Flight)
{
  this.flight=flight;
}
 public getFlight():Flight
{
  return this.flight;
}

  public setBooking( booking:Booking)
  {
      this.booking=booking;
  }

  public getBooking()
  {
      return this.booking;
  }

  public setBookDetail(bookDetails:BookingDetails){
    this.bookDetails=bookDetails;
  }

  public getBookDetail(){
    return this.bookDetails;
  }

  public setReturnDate(returnDate:string)
  {
    this.returnDate=returnDate
  }

  public getReturnDate(){
    return this.returnDate;
  }
}
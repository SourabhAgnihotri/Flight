import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { BookflightComponent } from './user/userview/bookflight/bookflight.component';
import { UserComponent} from './user/user.component';
import { UserviewComponent } from './user/userview/userview.component';
import { AddComponent } from './admin/add/add.component';
import { LoginComponent } from './login/login.component';
import { BookingdetailsComponent } from './user/bookingdetails/bookingdetails.component';
import { MyerrorComponent } from './myerror/myerror.component';

const routes: Routes = [
  { path: "login", component:LoginComponent},
  { path: "error", component:MyerrorComponent},
  { path: "search", component:BookingdetailsComponent},
  {path:"user",component:UserComponent,
  // children: [
  //   { path:"view/:classtype/:numberofseats",component:UserviewComponent},
  // ]
},
  { path:"view/:classtype/:numberofseats",component:UserviewComponent},
  {path:"booking/:classtype/:numberofseats",component:BookflightComponent},
  { path: "admin", loadChildren: ()=>import("./admin/admin.module").then(module=>module.AdminModule)},
  {path:"**",redirectTo:"user"}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

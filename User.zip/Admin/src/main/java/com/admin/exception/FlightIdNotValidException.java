package com.admin.exception;


public class FlightIdNotValidException extends Exception {
	
	public FlightIdNotValidException() {}
	
	public FlightIdNotValidException(String message)
		{
			super(message);
		}
}

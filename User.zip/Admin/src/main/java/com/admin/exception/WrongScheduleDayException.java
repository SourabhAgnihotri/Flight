package com.admin.exception;

public class WrongScheduleDayException extends Exception {
	
	public WrongScheduleDayException() {}
	
	public WrongScheduleDayException(String message)
		{
			super(message);
		}
}


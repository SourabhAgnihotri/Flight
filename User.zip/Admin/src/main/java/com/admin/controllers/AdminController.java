package com.admin.controllers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.admin.entity.Flight;
import com.admin.exception.WrongScheduleDayException;
import com.admin.services.FlightService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class AdminController {
	
	@Autowired
	private FlightService flightService;
	//Admin Get
	
	private static final String TOPIC = "kafka_topic";
	@Autowired
	private KafkaTemplate<String, List<String>> kafkaTemplate; 

	@GetMapping("/hello")
	public String hello()
	{
		return "Hello Admin";
	}
	
	
	@GetMapping("/view")
	public List<Flight> getAllRecords() throws Exception
	{
		return flightService.findAll();
	}
	
	@GetMapping("/search/{flightId}")
	public Flight getRecordsById(@PathVariable("flightId") int flightId) throws Exception
	{
		return flightService.findById(flightId);
		
	}
	
	@GetMapping("/search/airline/{airlines}")
	public List<Flight> getRecordsByAirline(@PathVariable("airlines") String airlines) throws Exception
	{
		return flightService.findByAirline(airlines);
	}
	
	//Admin Put
	
	@PutMapping("/manageschedule")
	public Flight manageSchedule(@RequestBody  Flight flight) throws Exception
	{
		List<String> datap=new ArrayList<>();
		datap.add(flight.getStartDate());
		datap.add(flight.getEndDate());
		kafkaTemplate.send(TOPIC, datap);
		Flight result= flightService.manageSchedule(flight);
		List<String> data=new ArrayList<>();
		data.add(flight.getStartDate());
		data.add(flight.getEndDate());
		
	kafkaTemplate.send(TOPIC, data);
	return result;
	}
	
	@PutMapping("/manageflight/status")
	public Flight manageFlights(@RequestBody Flight flight) throws Exception
	{
		return flightService.manageFlight(flight);
		
	}
	
	/*
	 * @GetMapping("/search/date")
	 * 
	 * public List<Flight> getRecordsById(@RequestParam String
	 * startDate,@RequestParam String endDate) { return
	 * flightService.findByDate(startDate,endDate); }
	 */
	
	@PutMapping("/update")
	public Flight update(@RequestBody Flight flight) throws Exception
	{
		return flightService.update(flight);
	}
	
	@DeleteMapping("/delete/{flightId}")
	public void delete(@PathVariable int flightId) throws Exception
	{
		flightService.deleteById(flightId);
		//return "Details of Flight ID: "+flightId+" is deleted successfully";
	}
	
	@PostMapping("/add")
	public Flight addRecords(@RequestBody  Flight flight) throws DataAccessException, WrongScheduleDayException
	
	{	if(FlightService.validateScheduleDays(flight))
		{
		try {
			return flightService.save(flight);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
		
		return null;
	}
}
package com.admin.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.beans.factory.annotation.Required;

@SuppressWarnings("deprecation")
@Entity()
@Table(name = "Flight")
public class Flight {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int flightId;
	
	
	private String airlines;
	
	private String fromLocation;
	
	private String toLocation;
	
	@Column(length = 200)
	 private String startDate;
	
	@Column(length = 200)
	private String endDate;
	
	private String scheduleDays;
	
	private String instrument;
	
	private int businessClassSeats;
	
	private int economyClassSeats;
	
	private double ticketCost;
	
	private int availableEconomySeats;
	
	private int availableBusinessSeats;
	
	//@ColumnDefault(value = "Activate")
	private String block;

	
	public Flight() {
		// TODO Auto-generated constructor stub
	}
	
	public Flight(String startDate,String endDate)
	{
		this.startDate=startDate;
		this.endDate=endDate;
				
	}
	
	public int getFlightId() {
		return flightId;
	}
	
	@Required
	public void setFlightId(int flightId) {
		this.flightId = flightId;
	}

	public String getAirlines() {
		return airlines;
	}
	@Required
	public void setAirlines(String airlines) {
		this.airlines = airlines;
	}

	public String getFromLocation() {
		return fromLocation;
	}
	@Required
	public void setFromLocation(String fromLocation) {
		this.fromLocation = fromLocation;
	}
	@Required
	public String getToLocation() {
		return toLocation;
	}
	@Required
	public void setToLocation(String toLocation) {
		this.toLocation = toLocation;
	}
	
	public String getStartDate() {
		return startDate;
	}
	@Required
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}
	@Required
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public String getScheduleDays() {
		return scheduleDays;
	}
	@Required
	public void setScheduleDays(String scheduleDays) {
		this.scheduleDays = scheduleDays;
	}

	public String getInstrument() {
		return instrument;
	}
	@Required
	public void setInstrument(String instrument) {
		this.instrument = instrument;
	}

	public int getBusinessClassSeats() {
		return businessClassSeats;
	}
	@Required
	public void setBusinessClassSeats(int businessClassSeats) {
		this.businessClassSeats = businessClassSeats;
	}

	public int getEconomyClassSeats() {
		return economyClassSeats;
	}
	@Required
	public void setEconomyClassSeats(int economyClassSeats) {
		this.economyClassSeats = economyClassSeats;
	}

	public double getTicketCost() {
		return ticketCost;
	}
	@Required
	public void setTicketCost(double ticketCost) {
		this.ticketCost = ticketCost;
	}

	public String getBlock() {
		return block;
	}
	@Required
	public void setBlock(String block) {
		this.block = block;
	}

	public int getAvailableEconomySeats() {
		return availableEconomySeats;
	}

	public void setAvailableEconomySeats(int availableEconomySeats) {
		this.availableEconomySeats = availableEconomySeats;
	}

	public int getAvailableBusinessSeats() {
		return availableBusinessSeats;
	}

	public void setAvailableBusinessSeats(int availableBusinessSeats) {
		this.availableBusinessSeats = availableBusinessSeats;
	}

	@Override
	public String toString() {
		return "Flight [flightId=" + flightId + ", airlines=" + airlines + ", fromLocation=" + fromLocation
				+ ", toLocation=" + toLocation + ", startDate=" + startDate + ", endDate=" + endDate + ", scheduleDays="
				+ scheduleDays + ", instrument=" + instrument + ", businessClassSeats=" + businessClassSeats
				+ ", economyClassSeats=" + economyClassSeats + ", ticketCost=" + ticketCost + ", availableEconomySeats="
				+ availableEconomySeats + ", availableBusinessSeats=" + availableBusinessSeats + ", block=" + block
				+ ", getFlightId()=" + getFlightId() + ", getAirlines()=" + getAirlines() + ", getFromLocation()="
				+ getFromLocation() + ", getToLocation()=" + getToLocation() + ", getStartDate()=" + getStartDate()
				+ ", getEndDate()=" + getEndDate() + ", getScheduleDays()=" + getScheduleDays() + ", getInstrument()="
				+ getInstrument() + ", getBusinessClassSeats()=" + getBusinessClassSeats() + ", getEconomyClassSeats()="
				+ getEconomyClassSeats() + ", getTicketCost()=" + getTicketCost() + ", getBlock()=" + getBlock()
				+ ", getAvailableEconomySeats()=" + getAvailableEconomySeats() + ", getAvailableBusinessSeats()="
				+ getAvailableBusinessSeats() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode()
				+ ", toString()=" + super.toString() + "]";
	}

	
	
}

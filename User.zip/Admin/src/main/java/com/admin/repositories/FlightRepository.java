package com.admin.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.admin.entity.Flight;



@Repository
public interface FlightRepository extends JpaRepository<Flight, Integer> {
	
	
	
	@Query(value = "SELECT * FROM flight f where f.start_date>= :startDate and f.start_date<= :endDate", nativeQuery = true)
	
	public List<Flight> findByStartDate( @Param("startDate") String startDate, @Param("endDate") String endDate);
	
	public List<Flight> findByAirlines(String airlines);

}

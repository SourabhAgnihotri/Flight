package com.admin.utils;

public class FlightConstants {

	public static final String FLIGHT_SCHEDULE_ALL_DAYS = "ALL";
	public static final String FLIGHT_SCHEDULE_WEEKDAYS = "WEEKDAYS";
	public static final String FLIGHT_SCHEDULE_WEEKENDS = "WEEKENDS";
	public static final String FLIGHT_SCHEDULE_SATURDAY = "SATURDAY";
	public static final String FLIGHT_SCHEDULE_SUNDAY = "SUNDAY";
}

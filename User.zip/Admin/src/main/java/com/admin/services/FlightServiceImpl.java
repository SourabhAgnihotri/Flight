package com.admin.services;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import com.admin.entity.Flight;
import com.admin.exception.FlightIdNotValidException;
import com.admin.repositories.FlightRepository;

@Service
public class FlightServiceImpl implements FlightService{

	
	
	@Autowired
	private FlightRepository flightRepository;
	
	@Override
	public List<Flight> findAll() throws Exception {
		// TODO Auto-generated method stub
		List<Flight> finalList=new ArrayList<>();
		try {
			return flightRepository.findAll();
		}
		catch(DataAccessException e) {
			throw new  Exception("Exception occurred while fetching flight details.");
		}
		
	}

	@Override
	public Flight findById(Integer flightId) throws Exception {
		// TODO Auto-generated method stub
		Optional<Flight> flight;
		try {
			 flight= flightRepository.findById(flightId);
			 if(flight.isPresent())
			 {
				 flight.get();
				
			 }
			 else {
				 throw new FlightIdNotValidException("INVALID FLIGHT ID");
			 }
		}
		catch(FlightIdNotValidException e) {
			throw new FlightIdNotValidException("INVALID FLIGHT ID");
		}
		catch(DataAccessException e) {
		throw new  Exception("Exception occurred while saving flight details.");
	}catch (Exception e) {
		throw new Exception("Exception occurred while saving");
	}
		return flight.get();
	}
	
	@Override
	public Flight save(Flight flight) throws Exception {
		
		Flight result;
		try {
			result= flightRepository.save(flight);
		}
		catch(DataAccessException e) {
			throw new Exception("Exception occurred while saving flight details.");
		}
		catch(Exception e) {
			throw new Exception("Exception occurred while saving flight details.");
		}
		return result;
	}
	
	@Override
	public Flight update(Flight flight) throws Exception {
		// TODO Auto-generated method stub
		Optional<Flight> flight1;
		try {	
		flight1=flightRepository.findById(flight.getFlightId());
		if(flight1.isPresent())
		{
			flight1.get().setAirlines(flight.getAirlines());
			flight1.get().setFromLocation(flight.getFromLocation());
			flight1.get().setToLocation(flight.getToLocation());
			flight1.get().setStartDate(flight.getStartDate());
			flight1.get().setStartDate(flight.getEndDate());
			flight1.get().setScheduleDays(flight.getScheduleDays());
			flight1.get().setInstrument(flight.getInstrument());
			flight1.get().setBusinessClassSeats(flight.getBusinessClassSeats());
			flight1.get().setEconomyClassSeats(flight.getEconomyClassSeats());
			flight1.get().setBlock(flight.getBlock());
			flight1.get().setAvailableBusinessSeats(flight.getAvailableBusinessSeats());
			flight1.get().setAvailableEconomySeats(flight.getAvailableEconomySeats());
		}
		 else {
			 throw new FlightIdNotValidException("INVALID FLIGHT ID");
		 }
	}
	catch(FlightIdNotValidException e) {
		throw new FlightIdNotValidException("INVALID FLIGHT ID");
	}catch(DataAccessException e) {
		throw new Exception("Exception occurred while updating flight details");
	}
	catch(Exception e) {
		throw new Exception("Exception occurred while updating");
	}
		
		return flightRepository.save(flight1.get());
	}

	@Override
	public void deleteById(Integer flightId) throws Exception {
		// TODO Auto-generated method stub
		try {
			flightRepository.deleteById(flightId);
		}
		catch(DataAccessException e) {
			throw new Exception("Exception Occured while deleting flight details");
		}
		catch (Exception e) {
			throw new Exception("Exception occurred while deleting");
		}
		
	}

	
	/*
	 * @Override public List<Flight> findByDate(String startDate,String endDate) {
	 * // TODO Aut-generated method stub return
	 * flightRepository.findByStartDate(startDate, endDate); }
	 */

	@Override
	public List<Flight> findByAirline(String airlines) throws Exception {
		
		List<Flight> flight=new ArrayList<>();
		
		try {
			flight.addAll(flightRepository.findByAirlines(airlines));
		}
		catch(DataAccessException e) {
			throw new Exception("Exception occurred while fetching Airlines details");
		}
		catch (Exception e) {
			throw new Exception("Exceptiom occurred while fetching Airlines");
		}
		return flight;
	}

	@Override
	public Flight manageSchedule(Flight flight) throws Exception  {
		try {
				Flight	flight1=flightRepository.getById(flight.getFlightId());
				if(flight1.getFlightId()==flight.getFlightId())
				{
					
					String startDate=flight.getStartDate();
					String endDate=flight.getEndDate();
					
					flight1.setStartDate(startDate);
					flight1.setEndDate(endDate);
					return flightRepository.save(flight1);
					
								
				}
				else {
					throw new FlightIdNotValidException("INVALID FLIGHT ID");
				}
		}catch(FlightIdNotValidException e) {
			throw new FlightIdNotValidException("INVALID FLIGHT ID");
		}
		/*
		 * catch (DataAccessException e) { throw new
		 * Exception("Error occurred while updating flight schedule"); } catch
		 * (Exception e) { throw new
		 * Exception("Error occurred while Managing flight schedule"); }
		 */
		
		
		
	
	}

	@Override
	public Flight manageFlight(Flight flight) throws Exception {
		// TODO Auto-generated method stub
		try {
			Optional<Flight> dbFlight=flightRepository.findById(flight.getFlightId());
			if(dbFlight.isPresent()) {
				dbFlight.get().setBlock(flight.getBlock());
				return flightRepository.save(dbFlight.get());
			}else {
				throw new FlightIdNotValidException("INVALID FLIGHT ID");
			}
		}	
			catch(FlightIdNotValidException e) {
				throw new FlightIdNotValidException("INVALID FLIGHT ID");
			}
		catch (DataAccessException e) {
			throw new Exception("Error occurred while updating flight status");
		}
			catch (Exception e) {
				throw new Exception("Error occurred while Managing flight status");
		}
		}
		
		
	
	
	

}
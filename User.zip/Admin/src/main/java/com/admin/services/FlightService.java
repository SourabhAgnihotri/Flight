package com.admin.services;

import java.sql.SQLDataException;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.springframework.stereotype.Service;

import com.admin.entity.Flight;
import com.admin.exception.WrongScheduleDayException;
import com.admin.utils.FlightConstants;

@Service
public interface FlightService {


	public List<Flight> findAll() throws   Exception;
	public Flight findById(Integer flightId) throws Exception;
	public List<Flight> findByAirline(String airlines) throws Exception;
	
	public Flight manageSchedule(Flight flight) throws Exception;
	public Flight manageFlight(Flight flightk) throws Exception;
	
	public Flight save(Flight flight) throws Exception;
	//public List<Flight> findByDate(String startDate,String endDate);
	public void deleteById(Integer flightId) throws Exception;
	public Flight update(Flight flight) throws Exception;
	//public void insertWithQuery(Flight flight);
	
	public static boolean validateScheduleDays(Flight flight) throws WrongScheduleDayException
	{

		String[] schedule=flight.getScheduleDays().split(",");
		DateTimeFormatter f1 = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
		LocalDate date = LocalDate.parse(flight.getStartDate(),f1);
		String day=date.getDayOfWeek().toString();
		
		if(FlightConstants.FLIGHT_SCHEDULE_ALL_DAYS.equalsIgnoreCase(flight.getScheduleDays()))
		{
			return true;
		}
		else if(FlightConstants.FLIGHT_SCHEDULE_WEEKDAYS.equalsIgnoreCase(flight.getScheduleDays()))
		{
			
			if(!(FlightConstants.FLIGHT_SCHEDULE_SATURDAY.equalsIgnoreCase(day) || FlightConstants.FLIGHT_SCHEDULE_SATURDAY.equalsIgnoreCase(day)))
			{
				return true;
			}
		}
		else if(FlightConstants.FLIGHT_SCHEDULE_WEEKENDS.equalsIgnoreCase(flight.getScheduleDays()))
		{
			
			if((FlightConstants.FLIGHT_SCHEDULE_SATURDAY.equalsIgnoreCase(day) || FlightConstants.FLIGHT_SCHEDULE_SATURDAY.equalsIgnoreCase(day)))
			{
				return true;
			}
		}
		else
		{
			for(String scDays:schedule)
			{
				if(scDays.equalsIgnoreCase(day))
				{
					return true;
				}
			}
		}
		
		throw new WrongScheduleDayException("INVALID SCHEDULE DAY");
		
	}
	
}
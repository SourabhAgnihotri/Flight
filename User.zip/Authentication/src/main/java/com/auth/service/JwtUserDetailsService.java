package com.auth.service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.auth.model.FlightBookingUsers;
import com.auth.repository.UserRespository;

@Service
public class JwtUserDetailsService implements UserDetailsService {

	@Autowired
	private UserRespository userRespository;
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		
		
		FlightBookingUsers user= userRespository.findByUserName(username);
		BCryptPasswordEncoder encoder = passwordEncoder();
	//BCryptPasswordEncoder en=new BCryptPasswordEncoder();
	//String pwd=en.encode(user.getPassword());
		if (user == null) {
			throw new UsernameNotFoundException("User not found with username: " + username);
		}
		return new org.springframework.security.core.userdetails.User(user.getUserName(), encoder.encode(user.getPassword()),getGrantedAuthorities(user));
	}
	
	@Bean
	private BCryptPasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}
	
	private Collection<GrantedAuthority> getGrantedAuthorities(FlightBookingUsers user){

	    Collection<GrantedAuthority> grantedAuthority = new ArrayList<>();
	   // if(true/*user.getRole().getName().equals("admin")*/)
	    if(user.getRole().equals("admin")){
	        grantedAuthority.add(new SimpleGrantedAuthority("ROLE_ADMIN"));
	    }else {
	    	grantedAuthority.add(new SimpleGrantedAuthority("ROLE_USER"));
	    }
	    
	    return grantedAuthority;
	}
	
	public String getRole(String username)
	{
		FlightBookingUsers user= userRespository.findByUserName(username);
		return user.getRole();
	}
}

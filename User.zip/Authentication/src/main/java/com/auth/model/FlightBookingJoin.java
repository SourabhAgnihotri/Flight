package com.auth.model;

import java.io.Serializable;

public class FlightBookingJoin implements Serializable {
	
	private int flightId;
	public FlightBookingJoin() {
		super();
	}
	public FlightBookingJoin(int flightId, String startDate, String endDate, String fromLocation, String toLocation) {
		super();
		this.flightId = flightId;
		this.startDate = startDate;
		this.endDate = endDate;
		this.fromLocation = fromLocation;
		this.toLocation = toLocation;
	}
	private String startDate; 
	private String endDate; 
	private String fromLocation;
	private String toLocation;
	public int getFlightId() {
		return flightId;
	}
	public void setFlightId(int flightId) {
		this.flightId = flightId;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public String getFromLocation() {
		return fromLocation;
	}
	public void setFromLocation(String fromLocation) {
		this.fromLocation = fromLocation;
	}
	public String getToLocation() {
		return toLocation;
	}
	public void setToLocation(String toLocation) {
		this.toLocation = toLocation;
	}
	@Override
	public String toString() {
		return "FlightBookingJoin [flightId=" + flightId + ", startDate=" + startDate + ", endDate=" + endDate
				+ ", fromLocation=" + fromLocation + ", toLocation=" + toLocation + "]";
	}

}

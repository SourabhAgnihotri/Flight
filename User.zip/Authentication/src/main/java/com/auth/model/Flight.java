package com.auth.model;

public class Flight {

	
	private int flightId;
	
	private String airlines;
	
	private String fromLocation;
	
	private String toLocation;
	
	
	 private String startDate;
	
	
	private String endDate;
	
	private String scheduleDays;
	
	private String instrument;
	
	private int businessClassSeats;
	
	private int economyClassSeats;
	
	private int availableBusinessSeats;
	
	private int availableEconomySeats;
	
	private double ticketCost;
	
	
	


	private String block;


	public int getFlightId() {
		return flightId;
	}


	public void setFlightId(int flightId) {
		this.flightId = flightId;
	}


	public String getAirlines() {
		return airlines;
	}


	public void setAirlines(String airlines) {
		this.airlines = airlines;
	}


	public String getFromLocation() {
		return fromLocation;
	}


	public void setFromLocation(String fromLocation) {
		this.fromLocation = fromLocation;
	}


	public String getToLocation() {
		return toLocation;
	}


	public void setToLocation(String toLocation) {
		this.toLocation = toLocation;
	}


	public String getStartDate() {
		return startDate;
	}


	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}


	public String getEndDate() {
		return endDate;
	}


	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}


	public String getScheduleDays() {
		return scheduleDays;
	}


	public void setScheduleDays(String scheduleDays) {
		this.scheduleDays = scheduleDays;
	}


	public String getInstrument() {
		return instrument;
	}


	public void setInstrument(String instrument) {
		this.instrument = instrument;
	}


	public int getBusinessClassSeats() {
		return businessClassSeats;
	}


	public void setBusinessClassSeats(int businessClassSeats) {
		this.businessClassSeats = businessClassSeats;
	}


	public int getEconomyClassSeats() {
		return economyClassSeats;
	}


	public void setEconomyClassSeats(int economyClassSeats) {
		this.economyClassSeats = economyClassSeats;
	}


	public double getTicketCost() {
		return ticketCost;
	}


	public void setTicketCost(double ticketCost) {
		this.ticketCost = ticketCost;
	}


	public String getBlock() {
		return block;
	}


	public void setBlock(String block) {
		this.block = block;
	}


	public int getAvailableBusinessSeats() {
		return availableBusinessSeats;
	}


	public void setAvailableBusinessSeats(int availableBusinessSeats) {
		this.availableBusinessSeats = availableBusinessSeats;
	}


	public int getAvailableEconomySeats() {
		return availableEconomySeats;
	}


	public void setAvailableEconomySeats(int availableEconomySeats) {
		this.availableEconomySeats = availableEconomySeats;
	}
}

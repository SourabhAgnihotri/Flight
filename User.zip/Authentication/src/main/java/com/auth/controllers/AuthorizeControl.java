package com.auth.controllers;


import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.auth.model.Booking;
import com.auth.model.Flight;
import com.auth.model.FlightBookingJoin;
import com.auth.service.JwtUserDetailsService;


@CrossOrigin
@RestController
public class AuthorizeControl {

	@Autowired
	private RestTemplate restTemplate;
	
	@Autowired
	private JwtUserDetailsService service;
	
	//@RequestHeader("Authorization")
	//@PreAuthorize("hasRole('')")
	@GetMapping("/hello")
	public String hello()
	{
		
		//authorization="Bearer"+"eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJyYW0iLCJleHAiOjE2NDE1ODYwMzgsImlhdCI6MTY0MTU2ODAzOH0.6dEizmoJgP9zGOJ0K4tqbZ3t1a8-sLv1eGOeHM38Rs54R7p6EUGXkz3JN0B9BWmtkEGUZNOUd_TuvSSUeiIOlg";
		return "Hello";
	}
	
	//ADMIN GET API
	
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	@GetMapping("/view")
	public List<Flight> getAllRecords()
	{
		String url="http://ADMIN-SERVICE/view";
		HttpMethod method=HttpMethod.GET;
		HttpEntity<?> requestEntity=new HttpEntity<>(null,null);
		ParameterizedTypeReference<List<Flight>> responeseType=new ParameterizedTypeReference<List<Flight>>() {};
		
		
		ResponseEntity<List<Flight>> res=   restTemplate.exchange(url, method, requestEntity, responeseType);
		return res.getBody();
	}
	
	@GetMapping("/search/{flightId}")
	public Flight searchById(@PathVariable("flightId") int flightId) 
	{
		String url="http://ADMIN-SERVICE/search/"+flightId;
		HttpMethod method=HttpMethod.GET;
		HttpEntity<?> requestEntity=new HttpEntity<>(null,null);
		ParameterizedTypeReference<Flight> responeseType=new ParameterizedTypeReference<Flight>() {};
		
		
		ResponseEntity<Flight> res=   restTemplate.exchange(url, method, requestEntity, responeseType);
		return res.getBody();
	}
	
	@GetMapping("/search/byAirline/{airlines}")
	public List<Flight> getRecordsByAirline(@PathVariable("airlines") String airlines) 
	{
		String url="http://ADMIN-SERVICE/search/airline/"+airlines;
		HttpMethod method=HttpMethod.GET;
		HttpEntity<?> requestEntity=new HttpEntity<>(null,null);
		ParameterizedTypeReference<List<Flight>> responeseType=new ParameterizedTypeReference<List<Flight>>() {};
		
		
		ResponseEntity<List<Flight>> res=   restTemplate.exchange(url, method, requestEntity, responeseType);
		return res.getBody();
	}
	
	
	
	//ADMIN PUT API
	
	@PutMapping("/manageflight/schedule")
	public Flight manageSchedule(@RequestBody Flight flight)
	{

		String url="http://ADMIN-SERVICE/manageschedule";
		HttpMethod method=HttpMethod.PUT;
		HttpEntity<Flight> requestEntity=new HttpEntity<>(flight,null);
		//ParameterizedTypeReference<Flight> responeseType=new ParameterizedTypeReference<Flight>() {};
		
		
		ResponseEntity<Flight> res=   restTemplate.exchange(url, method, requestEntity, Flight.class);
		return res.getBody();
	}
	
	@PutMapping("/manageflight/status")
	public Flight manageFlights(@RequestBody Flight flight)
	{
		String url="http://ADMIN-SERVICE/manageflight/status";
		HttpMethod method=HttpMethod.PUT;
		HttpEntity<Flight> requestEntity=new HttpEntity<>(flight,null);
		//ParameterizedTypeReference<Flight> responeseType=new ParameterizedTypeReference<Flight>() {};
		
		
		ResponseEntity<Flight> res=   restTemplate.exchange(url, method, requestEntity, Flight.class);
		return res.getBody();
	}
	
	@PreAuthorize("hasRole('ADMIN')")
	@PutMapping("/update")
	public Flight update(@RequestBody Flight flight) throws Exception
	{
		String url="http://ADMIN-SERVICE/update";
		HttpMethod method=HttpMethod.PUT;
		HttpEntity<Flight> requestEntity=new HttpEntity<>(flight,null);
		//ParameterizedTypeReference<Flight> responeseType=new ParameterizedTypeReference<Flight>() {};
		
		
		ResponseEntity<Flight> res=   restTemplate.exchange(url, method, requestEntity, Flight.class);
		return res.getBody();
	}
	
	
	//ADMIN POST API
	@PreAuthorize("hasRole('ADMIN')")
	@PostMapping("/add")
	public Flight addRecords(@RequestBody  Flight flight) 
	{
		String url="http://ADMIN-SERVICE/add";
		HttpMethod method=HttpMethod.POST;
		HttpEntity<Flight> requestEntity=new HttpEntity<>(flight,null);
		//ParameterizedTypeReference<Flight> responeseType=new ParameterizedTypeReference<Flight>() {};
		
		
		ResponseEntity<Flight> res=   restTemplate.exchange(url, method, requestEntity, Flight.class);
		return res.getBody();
	}
	
	//ADMIN DELETE API
	
	@DeleteMapping("/delete/{flightId}")
	public void delete(@PathVariable int flightId) 
	{
		String url="http://ADMIN-SERVICE/delete/"+flightId;
		HttpMethod method=HttpMethod.DELETE;
		HttpEntity<Flight> requestEntity=new HttpEntity<>(null,null);
		
		ResponseEntity<Void> res=   restTemplate.exchange(url, method, requestEntity,Void.class);
		//return res.getBody();
	}
	
	
	
	
	
	@PostMapping("/searchflight")
	public List<Flight> searchTrip(@RequestBody Flight flight, @RequestParam String classType,@RequestParam int numberOfSeats) throws Exception
	{
		
		String url="http://USER-SERVICE/searchflight/" + classType + "/" + numberOfSeats;
		HttpMethod method=HttpMethod.POST;
		//HttpEntity<?> requestEntity=new HttpEntity<>(null,null);
		HttpEntity<Flight> requestEntity=new HttpEntity<>(flight,null);
		ParameterizedTypeReference<List<Flight>> responeseType=new ParameterizedTypeReference<List<Flight>>() {};
		 
		ResponseEntity<List<Flight>> res=  restTemplate.exchange(url, method, requestEntity, responeseType);
		return res.getBody();
		
		
		
	}
	
	@PostMapping("/searchroundtrip")
	public List<Flight> searchRoundTrip(@RequestBody Flight flight, @RequestParam String returnDate, @RequestParam String classType,@RequestParam int numberOfSeats) throws Exception
	{
		
		String url="http://USER-SERVICE/searchRoundTrip/" + returnDate + "/" + classType + "/" + numberOfSeats;
		HttpMethod method=HttpMethod.POST;
		HttpEntity<Flight> requestEntity=new HttpEntity<>(flight,null);
		ParameterizedTypeReference<List<Flight>> responeseType=new ParameterizedTypeReference<List<Flight>>() {};
		 
		ResponseEntity<List<Flight>> res=  restTemplate.exchange(url, method, requestEntity, responeseType);
		return res.getBody();
		
		
		
	}
	
	@PostMapping("/bookflight")
	public List<Booking> bookFlight(@RequestBody List<com.auth.model.Booking> booking, @RequestParam int numberOfSeats,@RequestParam String classType,@RequestParam int flightId) throws Exception
	{
		
		String url="http://USER-SERVICE/bookflight/" + numberOfSeats + "/" + classType + "/" + flightId;
		HttpMethod method=HttpMethod.POST;
		HttpEntity<List<com.auth.model.Booking>> requestEntity=new HttpEntity<>(booking,null);
		ParameterizedTypeReference<List<com.auth.model.Booking>> responeseType=new ParameterizedTypeReference<List<com.auth.model.Booking>>() {};
		 
		ResponseEntity<List<Booking>> res=  restTemplate.exchange(url, method, requestEntity, responeseType);
		return res.getBody();
		
		
		
	}
	
	
	@GetMapping("/find/details/{pnr}")
	  public FlightBookingJoin findByPNR(@PathVariable String pnr)
	  {
		  
		
	  
		String url="http://USER-SERVICE/find/details/"+pnr;
		HttpMethod method=HttpMethod.GET;
		HttpEntity<?> requestEntity=new HttpEntity<>(null,null);
		ParameterizedTypeReference<FlightBookingJoin> responeseType=new ParameterizedTypeReference<FlightBookingJoin>() {};
		
		
		ResponseEntity<FlightBookingJoin> res=   restTemplate.exchange(url, method, requestEntity, responeseType);
		return res.getBody();
	}
	
	
	
	
	
}
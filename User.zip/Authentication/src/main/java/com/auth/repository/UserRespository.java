package com.auth.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.auth.model.FlightBookingUsers;

@Repository
public interface UserRespository extends JpaRepository<FlightBookingUsers, Integer>{
	
	@Query(value = "select * from flight_booking_users f where f.user_name=:userName", nativeQuery = true)
	public FlightBookingUsers findByUserName(@Param("userName") String userName);
	

	
	

}

package com.user;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.user.entities.Flight;
import com.user.repositories.FlightRepository;
import com.user.service.FlightService;

@SpringBootTest
class UserApplicationTests {

	@Autowired
	private FlightService service;
	
	@MockBean
	private FlightRepository repo;

	@Test
	public void shouldSearchFlight() throws Exception {
		
		Flight flight=new Flight( "Delhi", "Jammu and Kashmir","2022-05-22");
		List<Flight> al= new ArrayList<>();
		al.add(new Flight(1, "Vistara", "Delhi", "Jammu and Kashmir" ,"2022-05-22" ,"2022-05-22",
				30, 30, 15000, 30,
				30, "Active"));
		
		Mockito.when(repo.getAvailableEconomySeats(1)).thenReturn(30);
		
		
		Mockito.when(repo.searchFlight("2022-05-22","Delhi", "Jammu and Kashmir")).thenReturn(al);
		
		List<Flight> result=service.searchFlight(flight, "Economic", 1);
		
		Assertions.assertNotNull(result);
	}
	
	@Test
	public void shoullNotSearchFlight() {
		
		Flight flight=new Flight( "Delhi", "Jammu and Kashmir","2022-05-22");
		List<Flight> al= new ArrayList<>();
		al.add(new Flight(1, "Vistara", "Delhi", "Jammu and Kashmir" ,"2022-05-22" ,"2022-05-22",
				30, 30, 15000, 30,
				30, "Active"));
		
		Mockito.when(repo.getAvailableEconomySeats(1)).thenReturn(30);
		
		
		Mockito.when(repo.searchFlight("2022-05-22","Delhi", "Jammu and Kashmir")).thenReturn(null);
		
		//List<Flight> result=service.searchFlight(flight, "Economic", 1);
		
		Assertions.assertThrows(RuntimeException.class,  ()->{
			service.searchFlight(flight, "Economic", 1);});
	}

	@Test
	public void shouldSearchRoundTrip() throws Exception {
		
		Flight flight=new Flight( "Delhi", "Jammu and Kashmir","2022-05-22");
		List<Flight> al= new ArrayList<>();
		al.add(new Flight(1, "Vistara", "Delhi", "Jammu and Kashmir" ,"2022-05-22" ,"2022-05-22",
				30, 30, 15000, 30,
				30, "Active"));
		al.add(new Flight(2, "Vistara", "Jammu and Kashmir", "Delhi" ,"2022-05-25" ,"2022-05-25",
				30, 30, 15000, 30,
				30, "Active"));
		
		Mockito.when(repo.getAvailableEconomySeats(1)).thenReturn(30);
		Mockito.when(repo.getAvailableEconomySeats(2)).thenReturn(30);
		
		
		Mockito.when(repo.searchFlight("2022-05-22","Delhi", "Jammu and Kashmir")).thenReturn(al);
		
		List<Flight> result=service.searchRoundTrip(flight,"2022-05-25", "Economic", 1);
		
		Assertions.assertNotNull(result);
	}
	
	@Test
	public void shouldNotSearchRoundTrip() throws Exception {
		
		Flight flight=new Flight( "Delhi", "Jammu and Kashmir","2022-05-22");
		List<Flight> al= new ArrayList<>();
		al.add(new Flight(1, "Vistara", "Delhi", "Jammu and Kashmir" ,"2022-05-22" ,"2022-05-22",
				30, 30, 15000, 30,
				30, "Active"));
		al.add(new Flight(2, "Vistara", "Jammu and Kashmir", "Delhi" ,"2022-05-25" ,"2022-05-25",
				30, 30, 15000, 30,
				30, "Active"));
		
		Mockito.when(repo.getAvailableEconomySeats(1)).thenReturn(30);
		Mockito.when(repo.getAvailableEconomySeats(2)).thenReturn(30);
		
		
		Mockito.when(repo.searchFlight("2022-05-22","Delhi", "Jammu and Kashmir")).thenReturn(null);
		
		//List<Flight> result=service.searchRoundTrip(flight,"2022-05-28", "Economic", 1);
		
		Assertions.assertThrows(RuntimeException.class,  ()->{
			service.searchFlight(flight, "Economic", 1);});
	}
	
}

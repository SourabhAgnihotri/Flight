package com.user.entities;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Flight")
public class Flight {
	
	@Id
	private int flightId;
	
	
	private String airlines;
	
	private String fromLocation;
	
	private String toLocation;
	
	 private String startDate;
	
	private String endDate;
	
		
	private int businessClassSeats;
	
	private int economyClassSeats;
	
	private double ticketCost;
	
	private int availableEconomySeats;
	
	private int availableBusinessSeats;
	
	private String block;
	
	public Flight() {
		super();
	}

	public Flight(String fromLocation, String toLocation, String startDate) {
		super();
		this.fromLocation = fromLocation;
		this.toLocation = toLocation;
		this.startDate = startDate;
	}

	

	public Flight(int flightId, String airlines, String fromLocation, String toLocation, String startDate,
			String endDate, int businessClassSeats, int economyClassSeats, double ticketCost, int availableEconomySeats,
			int availableBusinessSeats, String block) {
		super();
		this.flightId = flightId;
		this.airlines = airlines;
		this.fromLocation = fromLocation;
		this.toLocation = toLocation;
		this.startDate = startDate;
		this.endDate = endDate;
		this.businessClassSeats = businessClassSeats;
		this.economyClassSeats = economyClassSeats;
		this.ticketCost = ticketCost;
		this.availableEconomySeats = availableEconomySeats;
		this.availableBusinessSeats = availableBusinessSeats;
		this.block = block;
	}

	public String getBlock() {
		return block;
	}

	public void setBlock(String block) {
		this.block = block;
	}

	public int getFlightId() {
		return flightId;
	}

	public void setFlightId(int flightId) {
		this.flightId = flightId;
	}

	public String getAirlines() {
		return airlines;
	}

	public void setAirlines(String airlines) {
		this.airlines = airlines;
	}

	public String getFromLocation() {
		return fromLocation;
	}

	public void setFromLocation(String fromLocation) {
		this.fromLocation = fromLocation;
	}

	public String getToLocation() {
		return toLocation;
	}

	public void setToLocation(String toLocation) {
		this.toLocation = toLocation;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public int getBusinessClassSeats() {
		return businessClassSeats;
	}

	public void setBusinessClassSeats(int businessClassSeats) {
		this.businessClassSeats = businessClassSeats;
	}

	public int getEconomyClassSeats() {
		return economyClassSeats;
	}

	public void setEconomyClassSeats(int economyClassSeats) {
		this.economyClassSeats = economyClassSeats;
	}

	public double getTicketCost() {
		return ticketCost;
	}

	public void setTicketCost(double ticketCost) {
		this.ticketCost = ticketCost;
	}

	public int getAvailableEconomySeats() {
		return availableEconomySeats;
	}

	public void setAvailableEconomySeats(int availableEconomySeats) {
		this.availableEconomySeats = availableEconomySeats;
	}

	public int getAvailableBusinessSeats() {
		return availableBusinessSeats;
	}

	public void setAvailableBusinessSeats(int availableBusinessSeats) {
		this.availableBusinessSeats = availableBusinessSeats;
	}

	@Override
	public String toString() {
		return "Flight [flightId=" + flightId + ", airlines=" + airlines + ", fromLocation=" + fromLocation
				+ ", toLocation=" + toLocation + ", startDate=" + startDate + ", endDate=" + endDate
				+ ", businessClassSeats=" + businessClassSeats + ", economyClassSeats=" + economyClassSeats
				+ ", ticketCost=" + ticketCost + ", availableEconomySeats=" + availableEconomySeats
				+ ", availableBusinessSeats=" + availableBusinessSeats + ", block=" + block + "]";
	}
	
}

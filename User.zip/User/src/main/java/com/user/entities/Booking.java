package com.user.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.hibernate.annotations.ColumnDefault;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class Booking {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int bookingId;
	private String airline;
	
	private String bookBy;
	private String bookFor;
	private String email;
	private int age;
	private String meal;
	private double tax;
	private double price;
	private String pnr;
	//private int numberOfSeats;
	private String classType;
	private int flightId;

	public String getAirline() {
		return airline;
	}


	public void setAirline(String airline) {
		this.airline = airline;
	}
	
	
	public String getClassType() {
		return classType;
	}

	public void setClassType(String classType) {
		this.classType = classType;
	}
	
	
	/*
	 * public int getNumberOfSeats() { return numberOfSeats; }
	 * 
	 * public void setNumberOfSeats(int numberOfSeats) { this.numberOfSeats =
	 * numberOfSeats; }
	 */

	public int getBookingId() {
		return bookingId;
	}
	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}
	public String getBookBy() {
		return bookBy;
	}
	public void setBookBy(String bookBy) {
		this.bookBy = bookBy;
	}
	public String getBookFor() {
		return bookFor;
	}
	public void setBookFor(String bookFor) {
		this.bookFor = bookFor;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getMeal() {
		return meal;
	}
	public void setMeal(String meal) {
		this.meal = meal;
	}
	public double getTax() {
		return tax;
	}
	public void setTax(double tax) {
		this.tax = tax;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public String getPnr() {
		return pnr;
	}
	public void setPnr(String pnr) {
		this.pnr = pnr;
	}
	public int getFlightId() {
		return flightId;
	}
	public void setFlightId(int flightId) {
		this.flightId = flightId;
	}

	@Override
	public String toString() {
		return "Booking [bookingId=" + bookingId + ", airline=" + airline + ", bookBy=" + bookBy
				+ ", bookFor=" + bookFor + ", email=" + email + ", age=" + age + ", meal=" + meal + ", tax=" + tax
				+ ", price=" + price + ", pnr=" + pnr + ", numberOfSeats="  + ", classType=" + classType
				+ ", flightId=" + flightId + "]";
	}
	
}

package com.user.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.user.entities.Flight;
import com.user.entities.FlightBookingJoin;

@Repository
public interface FlightRepository extends JpaRepository<Flight, Integer> {
	
	@Query(value = "SELECT * FROM flight f where date(f.start_date) =Date(:startDate) and f.from_location=:fromLocation and f.to_location=:toLocation", nativeQuery = true)
	
	public List<Flight> searchFlight( @Param("startDate") String startDate, @Param("fromLocation") String fromLocation,@Param("toLocation") String toLocation);
	
	@Query(value="SELECT f.available_economy_seats FROM flight f where f.flight_id=:flightId",nativeQuery = true)
	public int getAvailableEconomySeats(@Param("flightId") Integer flightId);
	
	@Query(value="SELECT f.available_business_seats FROM flight f where f.flight_id=:flightId",nativeQuery = true)
	public int getAvailableBusinessSeats(@Param("flightId") Integer flightId);
	
	@Query(value="SELECT f.airlines FROM flight f where f.flight_id=:flightId",nativeQuery = true)
	public String getAirlinesById(@Param("flightId") Integer flightId);
	
	@Transactional
	@Modifying(clearAutomatically = true)
	@Query(value = "UPDATE flight set available_economy_seats=available_economy_seats-1 where flight_id=:flightId",nativeQuery = true)
			public void updateAvailableEconomySeats(@Param("flightId") Integer flightId);
	
	@Transactional
	@Modifying(clearAutomatically = true)
	@Query(value = "UPDATE flight set available_business_seats=available_business_seats-1 where flight_id=:flightId",nativeQuery = true)
	public void updateAvailableBusinessSeats(@Param("flightId") Integer flightId);
	
	@Query(value="SELECT  *  FROM flight f where f.flight_id=:flightId",nativeQuery = true)
	public Flight findByPNR(@Param("flightId") Integer flightId);
	
}

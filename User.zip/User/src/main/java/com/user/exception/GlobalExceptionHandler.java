package com.user.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class GlobalExceptionHandler {

	@ExceptionHandler(FlightIdNotValidException.class)
	public ResponseEntity<String> handle(FlightIdNotValidException e)
	{
		return new ResponseEntity<String>(e.getMessage(),HttpStatus.OK);
	}
}

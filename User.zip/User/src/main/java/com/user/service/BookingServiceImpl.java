package com.user.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

import com.user.entities.Booking;
import com.user.entities.Flight;
import com.user.repositories.BookingRepository;
import com.user.repositories.FlightRepository;
import com.user.utilities.BookingUtilities;

@Service
public class BookingServiceImpl implements BookingService {

	@Autowired
	private BookingRepository bookingRepository;
	
	@Autowired
	private FlightRepository flightRepository;
	
	@Override
	public List<Booking> addBookingDetails(int numberOfSeats,String classType,int flightId,List<Booking> booking) throws Exception{
		// TODO Auto-generated method stub
		
		List<Booking> finalList=new ArrayList<>();
		
		
		try {
			if(BookingUtilities.validateClassTypeAndSeatsAvailability(numberOfSeats,classType,flightId))
				
				
			{
				for(Booking book:booking)
					
				{
					String pnr= "";
					BookingUtilities.calculateTicketCharges(classType ,flightId, book);
					book.setClassType(classType);
					book.setFlightId(flightId);
					//book.setBookingId("B"+(book.getId()+1)+flightId);
					pnr = BookingService.pnrGenerator(flightId) + book.getAirline();
					book.setPnr(pnr);
					
					Booking bookingDetails = bookingRepository.save(book);
					finalList.add(bookingDetails);
				}
				
			}
		}catch(DataAccessException exception) {
			throw new Exception("An Exception has occurred while saving data for add booking details.");
		}catch(Exception exception) {
			throw new Exception("An Exception has occurred while adding booking details.");
		}
			
			
		updateFlightDetails(finalList);	
				
		return finalList;
	}

	
	private void updateFlightDetails(List<Booking> bookigDetailList) {
		
		for(Booking booking : bookigDetailList) {
			System.err.println(booking);
			flightRepository.updateAvailableBusinessSeats(booking.getFlightId());
		}
		
	}


	@Override
	public int findByPNR(String pnr) {
	
		return bookingRepository.fingByPNR(pnr);
	}
	
	
	
}

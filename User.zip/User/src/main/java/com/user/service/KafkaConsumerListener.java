package com.user.service;

import java.util.List;

import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import com.user.entities.Flight;

@Service
public class KafkaConsumerListener {

    private static final String TOPIC = "kafka_topic";

    @KafkaListener(topics = TOPIC, groupId="group_id", containerFactory = "userKafkaListenerFactory")
    public void consumeJson(List<String> flight) {
        System.out.println("This flight is rescheduled:"+flight);
    	
    }
    
}
package com.user.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestParam;

import com.user.entities.Flight;
import com.user.entities.FlightBookingJoin;
import com.user.exception.FlightIdNotValidException;
import com.user.repositories.BookingRepository;
import com.user.repositories.FlightRepository;

@Service

public class FlightServiceImpl implements FlightService{
	
	@Autowired
	private FlightRepository flightRespository;
	
	@Autowired
	private BookingRepository bookingRepository;

	@Override
	public List<Flight> searchFlight(Flight flight,String classType, int numberOfSeats)throws Exception {
		List<Flight> flightList = new ArrayList<>();
			try {
				System.err.println(flight.getStartDate() + ", " );
				flightList= flightRespository.searchFlight(flight.getStartDate(),flight.getFromLocation(),flight.getToLocation());
				System.err.println(flightList);
				
				if(FlightService.validateData(flightList,classType,numberOfSeats).size()==0)
				{
					throw new FlightIdNotValidException("Currently flights are not available.");
				}
				
				
			}catch(FlightIdNotValidException exception) {
				throw new Exception("Currently flights are not available..");
			}
			catch(DataAccessException exception) {
				throw new Exception("An Exception has occurred while fetching data for  flight details.");
			}
			
		return FlightService.validateData(flightRespository.searchFlight(flight.getStartDate(),flight.getFromLocation(),flight.getToLocation()),classType,numberOfSeats);
	}

	@Override
	public List<Flight> searchRoundTrip(Flight flight, String returnDate,String classType, int numberOfSeats) throws Exception {
		// TODO Auto-generated method stub
		
		List<Flight> finalList=new ArrayList<>();
		try {
			finalList.addAll(FlightService.validateData(flightRespository.searchFlight(flight.getStartDate(),flight.getFromLocation(),flight.getToLocation()),classType,numberOfSeats));
			finalList.addAll(FlightService.validateData(flightRespository.searchFlight(returnDate, flight.getToLocation(),flight.getFromLocation()),classType,numberOfSeats));
			if(finalList.size()==0) {
			 throw new FlightIdNotValidException();
			}
		}
		catch(FlightIdNotValidException exception) {
			throw new Exception("Currently flights are not available..");
		}
		catch(DataAccessException exception) {
			throw new Exception("An Exception has occurred while fetching data for  flight details.");
		}catch(Exception exception) {
			throw new Exception("An Exception has occurred while fetching data for flight details.");
		}
	
		
		 //(flightRespository.searchFlight(startDate,fromLocation, toLocation))
		
		
		 return finalList;
		 
	}
	
public FlightBookingJoin findByPNR(String pnr){
		
		int flightId=bookingRepository.fingByPNR(pnr);
		Flight flight=flightRespository.findByPNR(flightId);
		FlightBookingJoin fbj=new FlightBookingJoin();
		if(flight!=null)
		{
			fbj.setFlightId(flight.getFlightId());
			fbj.setFromLocation(flight.getFromLocation());
			fbj.setToLocation(flight.getToLocation());
			fbj.setStartDate(flight.getStartDate());
			fbj.setEndDate(flight.getEndDate());
			
		}
		//KafkaConsumerListener kcl=new KafkaConsumerListener();
		
		return fbj;
	}

}

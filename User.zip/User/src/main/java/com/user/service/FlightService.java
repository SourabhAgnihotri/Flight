package com.user.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.user.entities.Flight;
import com.user.entities.FlightBookingJoin;
import com.user.exception.FlightIdNotValidException;
import com.user.utilities.BookingUtilities;

@Service
public interface FlightService {
	
	public List<Flight> searchFlight(Flight flight, String classType, int numberOfSeats) throws Exception;
	
	public FlightBookingJoin findByPNR(String pnr);
	
	public List<Flight> searchRoundTrip(Flight flight,String returnDate, String classType, int numberOfSeats) throws Exception;
	
	public static List<Flight> validateData(List<Flight> flight, String classType, int numberOfSeats)
	{String str;
		//light f=flight.get(0);
		List<Flight> finalList=new ArrayList<>();
		for(Flight temp:flight)
		{
			
			if(temp.getBlock().equalsIgnoreCase("Active") && BookingUtilities.validateClassTypeAndSeatsAvailability(numberOfSeats, classType, temp.getFlightId())/*temp.getBlock().contains("Active")*/)
			{
				finalList.add(temp);
			}
		}
		return finalList;
	}
	

	
}

package com.user.service;

import java.util.List;
import java.util.Random;

import org.springframework.stereotype.Service;

import com.user.entities.Booking;
import com.user.entities.Flight;

@Service
public interface BookingService {
	
	
	
	public int findByPNR(String pnr);
	
	public List<Booking> addBookingDetails(int numberOfSeats,String classType,int flight_Id,List<Booking> booking) throws Exception;
	
	public static int pnrGenerator(int flightId) {
		Random generator = new Random();
		return Math.abs(generator.nextInt(flightId*1000));
	}
	
}

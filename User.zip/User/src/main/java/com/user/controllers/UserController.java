package com.user.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.user.entities.Booking;
import com.user.entities.Flight;
import com.user.entities.FlightBookingJoin;
import com.user.service.BookingService;
import com.user.service.FlightService;

@RestController
//@RequestMapping("/user")
public class UserController {
	
	@Autowired
	private FlightService flightService;
	
	@Autowired
	private BookingService bookingService;
	
	/*
	 * @GetMapping("/searchflight/{classType}/{numberOfSeats}") public List<Flight>
	 * searchFlight(@RequestBody Flight flight,@PathVariable String
	 * classType,@PathVariable String numberOfSeats) throws Exception {
	 * 
	 * 
	 * return
	 * flightService.searchFlight(flight,classType,Integer.parseInt(numberOfSeats));
	 * 
	 * 
	 * }
	 */
	
	@PostMapping("/searchflight/{classType}/{numberOfSeats}")
	public List<Flight> searchFlight(@RequestBody Flight flight,@PathVariable("classType") String classType,@PathVariable("numberOfSeats") int numberOfSeats) throws Exception
	{
	
		
		//return "success"+classType+numberOfSeats;		
		return flightService.searchFlight(flight,classType,numberOfSeats);
			
		
	}
	
	@PostMapping("/searchRoundTrip/{returnDate}/{classType}/{numberOfSeats}")
	public List<Flight> searchRoundTrip(@RequestBody Flight flight,@PathVariable String returnDate,@PathVariable String classType,@PathVariable int numberOfSeats) throws Exception
	{
		
		return flightService.searchRoundTrip(flight,returnDate,classType,numberOfSeats);
	}
	
	
	  @PostMapping("/bookflight/{numberOfSeats}/{classType}/{flightId}") 
	  public List<Booking> flightBooking(@PathVariable int numberOfSeats,@PathVariable String classType,@PathVariable int flightId,@RequestBody List<Booking> booking) throws Exception
	  {
		  return bookingService.addBookingDetails(numberOfSeats, classType, flightId,booking);
	  }
	 
	  @GetMapping("/hello")
		public String Hello() throws Exception
		{
			
			return "Hello";
		}
	  
	  @GetMapping("/find/details/{pnr}")
	  public FlightBookingJoin findByPNR(@PathVariable String pnr)
	  {
		  
		return  flightService.findByPNR(pnr);
	  }
	
}

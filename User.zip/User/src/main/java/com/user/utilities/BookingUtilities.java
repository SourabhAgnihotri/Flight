package com.user.utilities;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.user.entities.Booking;
import com.user.repositories.FlightRepository;

@Component
public class BookingUtilities {
	
	@Autowired
	private static FlightRepository flightRepository;
	
	public static String ECONOMIC_TYPE="ECONOMIC";
	public static String BUSISNES_TYPE="BUSINESS";
	
	@Autowired
    public void setFlightRepository(FlightRepository flightRepository){
        BookingUtilities.flightRepository = flightRepository;
	}
	public  static boolean validateClassTypeAndSeatsAvailability(int numberOfSeats,String classType,int flight_id)
	{
			int availableSeats = flightRepository.getAvailableEconomySeats(flight_id);
		
			if(ECONOMIC_TYPE.equalsIgnoreCase(classType))
			{
				if(numberOfSeats<= availableSeats)
				{
					return true;
				}
		}
		else if(BUSISNES_TYPE.equalsIgnoreCase(classType))
		{
			availableSeats = flightRepository.getAvailableBusinessSeats(flight_id);
			if(numberOfSeats<=availableSeats)
			{
				return true;
			}
			//if(booking.getNumberOfSeats()<=flightRepository.getAvailableBusinessSeats(booking.getFlightId()))
			/*
			 * booking.setTax(20); if(booking.getMeal().equalsIgnoreCase("YES")) { double
			 * price=booking.getPrice()+1000+(booking.getPrice()*(booking.getTax()/100));
			 * booking.setPrice(price); return true; } else
			 * if(booking.getMeal().equalsIgnoreCase("NO")) { double
			 * price=booking.getPrice()+1000+(booking.getPrice()*(booking.getTax()/100));
			 * booking.setPrice(price); return true; }
			 */
			
		}
		
		
		
		
		return false;
	}
	
	
	public static void calculateTicketCharges(String classType,int flightId,Booking booking)
	{
		if(ECONOMIC_TYPE.equalsIgnoreCase(classType))
		{
			
			  booking.setTax(10);
			  flightRepository.updateAvailableEconomySeats(flightId);
			  
			  booking.setAirline(flightRepository.getAirlinesById(flightId));
			  if(booking.getMeal().equalsIgnoreCase("YES")) 
			  { 					  
				  double price=booking.getPrice()+500+(booking.getPrice()*(booking.getTax()/100));
			  	  booking.setPrice(price); 
			  		
			  } else if(booking.getMeal().equalsIgnoreCase("NO"))
			  
				  {
					  double price=booking.getPrice()+(booking.getPrice()*(booking.getTax()/100));
				  
					  booking.setPrice(price);
				  }
			 
		}
		else if(BUSISNES_TYPE.equalsIgnoreCase(classType))
		{
			  booking.setTax(20);
			  booking.setAirline(flightRepository.getAirlinesById(flightId));
			  if(booking.getMeal().equalsIgnoreCase("YES")) 
			  { 					  
				  double price=booking.getPrice()+1000+(booking.getPrice()*(booking.getTax()/100));
			  	  booking.setPrice(price); 
			  		
			  } else  if(booking.getMeal().equalsIgnoreCase("NO"))
			 
			  {
				  double price=booking.getPrice()+(booking.getPrice()*(booking.getTax()/100));
			  
				  booking.setPrice(price);
			  }
			
		}
	}
	

}
